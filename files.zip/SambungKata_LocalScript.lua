-- =============================================
-- SAMBUNG KATA - LOCAL SCRIPT (GUI)
-- Letakkan di: StarterPlayerScripts > SambungKataGUI
-- =============================================

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local playerGui = player.PlayerGui

-- Tunggu Remotes siap
local Remotes = ReplicatedStorage:WaitForChild("Remotes", 10)
if not Remotes then error("Remotes folder tidak ditemukan!") end

local RemoteSubmitWord = Remotes:WaitForChild("SubmitWord")
local RemoteUpdateUI   = Remotes:WaitForChild("UpdateUI")
local RemoteGameState  = Remotes:WaitForChild("GameState")
local RemoteNotify     = Remotes:WaitForChild("Notify")
local StartGameRemote  = Remotes:WaitForChild("StartGame")

-- =============================================
-- BUAT GUI
-- =============================================
local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "SambungKataGUI"
ScreenGui.ResetOnSpawn = false
ScreenGui.Parent = playerGui

-- =============================================
-- WARNA & STYLE
-- =============================================
local COLORS = {
	primary    = Color3.fromRGB(30, 30, 46),
	secondary  = Color3.fromRGB(49, 50, 68),
	accent     = Color3.fromRGB(137, 180, 250),
	green      = Color3.fromRGB(166, 227, 161),
	red        = Color3.fromRGB(243, 139, 168),
	yellow     = Color3.fromRGB(249, 226, 175),
	text       = Color3.fromRGB(205, 214, 244),
	textDim    = Color3.fromRGB(127, 132, 156),
	white      = Color3.fromRGB(255, 255, 255),
}

-- =============================================
-- PANEL UTAMA
-- =============================================
local MainFrame = Instance.new("Frame")
MainFrame.Name = "MainFrame"
MainFrame.Size = UDim2.new(0, 400, 0, 580)
MainFrame.Position = UDim2.new(0.5, -200, 0.5, -290)
MainFrame.BackgroundColor3 = COLORS.primary
MainFrame.BorderSizePixel = 0
MainFrame.Parent = ScreenGui

local MainCorner = Instance.new("UICorner")
MainCorner.CornerRadius = UDim.new(0, 16)
MainCorner.Parent = MainFrame

local MainStroke = Instance.new("UIStroke")
MainStroke.Color = COLORS.accent
MainStroke.Thickness = 2
MainStroke.Parent = MainFrame

-- =============================================
-- HEADER
-- =============================================
local Header = Instance.new("Frame")
Header.Size = UDim2.new(1, 0, 0, 70)
Header.Position = UDim2.new(0, 0, 0, 0)
Header.BackgroundColor3 = COLORS.secondary
Header.BorderSizePixel = 0
Header.Parent = MainFrame

local HeaderCorner = Instance.new("UICorner")
HeaderCorner.CornerRadius = UDim.new(0, 16)
HeaderCorner.Parent = Header

-- Fix corner bawah header
local HeaderFix = Instance.new("Frame")
HeaderFix.Size = UDim2.new(1, 0, 0, 16)
HeaderFix.Position = UDim2.new(0, 0, 1, -16)
HeaderFix.BackgroundColor3 = COLORS.secondary
HeaderFix.BorderSizePixel = 0
HeaderFix.Parent = Header

local TitleLabel = Instance.new("TextLabel")
TitleLabel.Text = "🔤 SAMBUNG KATA"
TitleLabel.Size = UDim2.new(1, 0, 1, 0)
TitleLabel.BackgroundTransparency = 1
TitleLabel.TextColor3 = COLORS.accent
TitleLabel.TextSize = 22
TitleLabel.Font = Enum.Font.GothamBold
TitleLabel.Parent = Header

-- =============================================
-- KATA SAAT INI
-- =============================================
local WordDisplay = Instance.new("Frame")
WordDisplay.Size = UDim2.new(1, -30, 0, 90)
WordDisplay.Position = UDim2.new(0, 15, 0, 80)
WordDisplay.BackgroundColor3 = COLORS.secondary
WordDisplay.BorderSizePixel = 0
WordDisplay.Parent = MainFrame

local WDCorner = Instance.new("UICorner")
WDCorner.CornerRadius = UDim.new(0, 12)
WDCorner.Parent = WordDisplay

local CurrentWordLabel = Instance.new("TextLabel")
CurrentWordLabel.Name = "CurrentWord"
CurrentWordLabel.Text = "Menunggu game dimulai..."
CurrentWordLabel.Size = UDim2.new(1, 0, 0.5, 0)
CurrentWordLabel.Position = UDim2.new(0, 0, 0, 0)
CurrentWordLabel.BackgroundTransparency = 1
CurrentWordLabel.TextColor3 = COLORS.white
CurrentWordLabel.TextSize = 24
CurrentWordLabel.Font = Enum.Font.GothamBold
CurrentWordLabel.Parent = WordDisplay

local LastLetterLabel = Instance.new("TextLabel")
LastLetterLabel.Name = "LastLetter"
LastLetterLabel.Text = "Sambung dengan huruf: -"
LastLetterLabel.Size = UDim2.new(1, 0, 0.5, 0)
LastLetterLabel.Position = UDim2.new(0, 0, 0.5, 0)
LastLetterLabel.BackgroundTransparency = 1
LastLetterLabel.TextColor3 = COLORS.accent
LastLetterLabel.TextSize = 16
LastLetterLabel.Font = Enum.Font.Gotham
LastLetterLabel.Parent = WordDisplay

-- =============================================
-- INFO GILIRAN + TIMER
-- =============================================
local TurnFrame = Instance.new("Frame")
TurnFrame.Size = UDim2.new(1, -30, 0, 50)
TurnFrame.Position = UDim2.new(0, 15, 0, 180)
TurnFrame.BackgroundColor3 = COLORS.secondary
TurnFrame.BorderSizePixel = 0
TurnFrame.Parent = MainFrame

local TFCorner = Instance.new("UICorner")
TFCorner.CornerRadius = UDim.new(0, 12)
TFCorner.Parent = TurnFrame

local TurnLabel = Instance.new("TextLabel")
TurnLabel.Name = "TurnInfo"
TurnLabel.Text = "Giliran: -"
TurnLabel.Size = UDim2.new(0.65, 0, 1, 0)
TurnLabel.Position = UDim2.new(0, 10, 0, 0)
TurnLabel.BackgroundTransparency = 1
TurnLabel.TextColor3 = COLORS.text
TurnLabel.TextSize = 15
TurnLabel.Font = Enum.Font.Gotham
TurnLabel.TextXAlignment = Enum.TextXAlignment.Left
TurnLabel.Parent = TurnFrame

local TimerLabel = Instance.new("TextLabel")
TimerLabel.Name = "Timer"
TimerLabel.Text = "⏱ -"
TimerLabel.Size = UDim2.new(0.3, 0, 1, 0)
TimerLabel.Position = UDim2.new(0.7, 0, 0, 0)
TimerLabel.BackgroundTransparency = 1
TimerLabel.TextColor3 = COLORS.yellow
TimerLabel.TextSize = 18
TimerLabel.Font = Enum.Font.GothamBold
TimerLabel.Parent = TurnFrame

-- =============================================
-- INPUT KATA
-- =============================================
local InputFrame = Instance.new("Frame")
InputFrame.Size = UDim2.new(1, -30, 0, 55)
InputFrame.Position = UDim2.new(0, 15, 0, 242)
InputFrame.BackgroundColor3 = COLORS.secondary
InputFrame.BorderSizePixel = 0
InputFrame.Parent = MainFrame

local IFCorner = Instance.new("UICorner")
IFCorner.CornerRadius = UDim.new(0, 12)
IFCorner.Parent = InputFrame

local WordInput = Instance.new("TextBox")
WordInput.Name = "WordInput"
WordInput.PlaceholderText = "Ketik kata di sini..."
WordInput.Text = ""
WordInput.Size = UDim2.new(0.7, -5, 1, -10)
WordInput.Position = UDim2.new(0, 5, 0, 5)
WordInput.BackgroundColor3 = COLORS.primary
WordInput.TextColor3 = COLORS.white
WordInput.PlaceholderColor3 = COLORS.textDim
WordInput.TextSize = 16
WordInput.Font = Enum.Font.Gotham
WordInput.ClearTextOnFocus = false
WordInput.BorderSizePixel = 0
WordInput.Parent = InputFrame

local ICorner = Instance.new("UICorner")
ICorner.CornerRadius = UDim.new(0, 8)
ICorner.Parent = WordInput

local SubmitBtn = Instance.new("TextButton")
SubmitBtn.Text = "KIRIM"
SubmitBtn.Size = UDim2.new(0.28, 0, 1, -10)
SubmitBtn.Position = UDim2.new(0.72, 0, 0, 5)
SubmitBtn.BackgroundColor3 = COLORS.accent
SubmitBtn.TextColor3 = COLORS.primary
SubmitBtn.TextSize = 14
SubmitBtn.Font = Enum.Font.GothamBold
SubmitBtn.BorderSizePixel = 0
SubmitBtn.Parent = InputFrame

local SBCorner = Instance.new("UICorner")
SBCorner.CornerRadius = UDim.new(0, 8)
SBCorner.Parent = SubmitBtn

-- =============================================
-- NOTIFIKASI
-- =============================================
local NotifLabel = Instance.new("TextLabel")
NotifLabel.Name = "Notif"
NotifLabel.Text = ""
NotifLabel.Size = UDim2.new(1, -30, 0, 35)
NotifLabel.Position = UDim2.new(0, 15, 0, 307)
NotifLabel.BackgroundColor3 = COLORS.secondary
NotifLabel.BackgroundTransparency = 1
NotifLabel.TextColor3 = COLORS.green
NotifLabel.TextSize = 14
NotifLabel.Font = Enum.Font.Gotham
NotifLabel.TextWrapped = true
NotifLabel.Parent = MainFrame

-- =============================================
-- SCOREBOARD
-- =============================================
local ScoreHeader = Instance.new("TextLabel")
ScoreHeader.Text = "🏆 SKOR"
ScoreHeader.Size = UDim2.new(1, -30, 0, 25)
ScoreHeader.Position = UDim2.new(0, 15, 0, 350)
ScoreHeader.BackgroundTransparency = 1
ScoreHeader.TextColor3 = COLORS.accent
ScoreHeader.TextSize = 14
ScoreHeader.Font = Enum.Font.GothamBold
ScoreHeader.TextXAlignment = Enum.TextXAlignment.Left
ScoreHeader.Parent = MainFrame

local ScoreFrame = Instance.new("ScrollingFrame")
ScoreFrame.Name = "ScoreFrame"
ScoreFrame.Size = UDim2.new(1, -30, 0, 130)
ScoreFrame.Position = UDim2.new(0, 15, 0, 378)
ScoreFrame.BackgroundColor3 = COLORS.secondary
ScoreFrame.BorderSizePixel = 0
ScoreFrame.ScrollBarThickness = 4
ScoreFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
ScoreFrame.Parent = MainFrame

local SFCorner = Instance.new("UICorner")
SFCorner.CornerRadius = UDim.new(0, 12)
SFCorner.Parent = ScoreFrame

local ScoreLayout = Instance.new("UIListLayout")
ScoreLayout.Padding = UDim.new(0, 4)
ScoreLayout.Parent = ScoreFrame

-- =============================================
-- TOMBOL START
-- =============================================
local StartBtn = Instance.new("TextButton")
StartBtn.Text = "▶ MULAI GAME"
StartBtn.Size = UDim2.new(1, -30, 0, 45)
StartBtn.Position = UDim2.new(0, 15, 0, 520)
StartBtn.BackgroundColor3 = COLORS.green
StartBtn.TextColor3 = COLORS.primary
StartBtn.TextSize = 16
StartBtn.Font = Enum.Font.GothamBold
StartBtn.BorderSizePixel = 0
StartBtn.Parent = MainFrame

local StartCorner = Instance.new("UICorner")
StartCorner.CornerRadius = UDim.new(0, 12)
StartCorner.Parent = StartBtn

-- =============================================
-- FUNGSI HELPER GUI
-- =============================================
local timerThread = nil
local currentTimeLimit = 15

local function showNotif(msg, color)
	NotifLabel.Text = msg
	NotifLabel.TextColor3 = color or COLORS.green
	task.delay(4, function()
		if NotifLabel.Text == msg then
			NotifLabel.Text = ""
		end
	end)
end

local function startTimer(seconds)
	currentTimeLimit = seconds
	if timerThread then task.cancel(timerThread) end
	timerThread = task.spawn(function()
		for i = seconds, 0, -1 do
			TimerLabel.Text = "⏱ " .. i .. "s"
			if i <= 5 then
				TimerLabel.TextColor3 = COLORS.red
			elseif i <= 10 then
				TimerLabel.TextColor3 = COLORS.yellow
			else
				TimerLabel.TextColor3 = COLORS.green
			end
			task.wait(1)
		end
	end)
end

local function updateScoreboard(data)
	-- Hapus semua score label lama
	for _, child in ipairs(ScoreFrame:GetChildren()) do
		if child:IsA("Frame") then child:Destroy() end
	end

	local medals = {"🥇", "🥈", "🥉"}
	for i, entry in ipairs(data) do
		local row = Instance.new("Frame")
		row.Size = UDim2.new(1, -10, 0, 30)
		row.BackgroundTransparency = 1
		row.Parent = ScoreFrame

		local rankLabel = Instance.new("TextLabel")
		rankLabel.Text = (medals[i] or tostring(i) .. ".") .. " " .. entry.name
		rankLabel.Size = UDim2.new(0.7, 0, 1, 0)
		rankLabel.Position = UDim2.new(0, 8, 0, 0)
		rankLabel.BackgroundTransparency = 1
		rankLabel.TextColor3 = COLORS.text
		rankLabel.TextSize = 14
		rankLabel.Font = Enum.Font.Gotham
		rankLabel.TextXAlignment = Enum.TextXAlignment.Left
		rankLabel.Parent = row

		local scoreLabel = Instance.new("TextLabel")
		scoreLabel.Text = tostring(entry.score) .. " pts"
		scoreLabel.Size = UDim2.new(0.28, 0, 1, 0)
		scoreLabel.Position = UDim2.new(0.72, 0, 0, 0)
		scoreLabel.BackgroundTransparency = 1
		scoreLabel.TextColor3 = COLORS.accent
		scoreLabel.TextSize = 14
		scoreLabel.Font = Enum.Font.GothamBold
		scoreLabel.Parent = row
	end

	ScoreFrame.CanvasSize = UDim2.new(0, 0, 0, #data * 34)
end

-- =============================================
-- TOMBOL SUBMIT
-- =============================================
local function submitWord()
	local word = WordInput.Text
	if word == "" then return end
	RemoteSubmitWord:FireServer(word)
	WordInput.Text = ""
end

SubmitBtn.MouseButton1Click:Connect(submitWord)
WordInput.FocusLost:Connect(function(enterPressed)
	if enterPressed then submitWord() end
end)

-- =============================================
-- TOMBOL START
-- =============================================
StartBtn.MouseButton1Click:Connect(function()
	StartGameRemote:FireServer()
end)

-- =============================================
-- TERIMA UPDATE DARI SERVER
-- =============================================
RemoteUpdateUI.OnClientEvent:Connect(function(eventType, data)
	if eventType == "turn" then
		CurrentWordLabel.Text = "💬 " .. string.upper(data.currentWord)
		LastLetterLabel.Text = "Sambung dengan huruf: " .. data.lastLetter
		TurnLabel.Text = "Giliran: " .. data.playerName
		startTimer(data.timeLimit)
	elseif eventType == "scoreboard" then
		updateScoreboard(data)
	end
end)

RemoteNotify.OnClientEvent:Connect(function(eventType, data, extra)
	if eventType == "yourTurn" then
		showNotif("🎯 Giliran KAMU! Kata harus dimulai huruf: " .. string.upper(data), COLORS.yellow)
	elseif eventType == "wordAccepted" then
		showNotif("✅ " .. data.playerName .. ": '" .. data.word .. "' — Lanjut ke huruf " .. data.lastLetter, COLORS.green)
	elseif eventType == "eliminated" then
		showNotif("❌ " .. data .. " tereliminasi: " .. (extra or ""), COLORS.red)
	elseif eventType == "error" then
		showNotif("⚠️ " .. data, COLORS.red)
	elseif eventType == "info" then
		showNotif("ℹ️ " .. data, COLORS.text)
	end
end)

RemoteGameState.OnClientEvent:Connect(function(eventType, data)
	if eventType == "gameStart" then
		CurrentWordLabel.Text = "💬 " .. string.upper(data.word)
		LastLetterLabel.Text = "Sambung dengan huruf: " .. data.lastLetter
		StartBtn.Text = "🔄 RESTART"
		showNotif("🎮 Game dimulai! Urutan: " .. table.concat(data.playerOrder, " → "), COLORS.accent)
	elseif eventType == "gameOver" then
		if timerThread then task.cancel(timerThread) end
		TimerLabel.Text = "⏱ -"
		TurnLabel.Text = "Game selesai!"
		CurrentWordLabel.Text = "🏆 Pemenang: " .. data
		LastLetterLabel.Text = "Tekan MULAI GAME untuk main lagi!"
		StartBtn.Text = "▶ MAIN LAGI"
		showNotif("🎉 " .. data .. " MENANG!", COLORS.yellow)
	elseif eventType == "welcome" then
		if data.isRunning then
			CurrentWordLabel.Text = "💬 " .. string.upper(data.currentWord)
			LastLetterLabel.Text = "Sambung dengan huruf: " .. data.lastLetter
		end
	end
end)

print("[SambungKata] GUI loaded untuk " .. player.Name)
