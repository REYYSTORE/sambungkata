# 📖 PANDUAN INSTALASI — SAMBUNG KATA (Roblox Studio)

## 📁 File yang Ada
- `SambungKata_ServerScript.lua` → Script utama game (server)
- `SambungKata_LocalScript.lua` → GUI & tampilan (client)

---

## 🛠️ LANGKAH INSTALASI

### 1. Buka Roblox Studio
- Buat game baru atau buka project yang sudah ada

### 2. Pasang Server Script
- Di panel **Explorer**, buka: `ServerScriptService`
- Klik kanan → Insert Object → **Script**
- Rename menjadi: `GameScript`
- Copy-paste isi `SambungKata_ServerScript.lua` ke dalam script tersebut

### 3. Pasang Local Script (GUI)
- Di panel **Explorer**, buka: `StarterPlayer` → `StarterPlayerScripts`
- Klik kanan → Insert Object → **LocalScript**
- Rename menjadi: `SambungKataGUI`
- Copy-paste isi `SambungKata_LocalScript.lua` ke dalam script tersebut

### 4. Test Game
- Klik tombol **Play** (atau tekan F5)
- Untuk simulasi multiplayer: klik dropdown ▼ di sebelah Play → pilih **"Start Server"** lalu buka beberapa client

---

## 🎮 CARA BERMAIN

1. Klik **"▶ MULAI GAME"** (butuh minimal 2 pemain)
2. Sistem akan menampilkan kata pertama otomatis
3. Pemain yang mendapat giliran harus mengetik kata yang:
   - ✅ Dimulai dengan **huruf terakhir** kata sebelumnya
   - ✅ Ada di **kamus** yang tersedia
   - ✅ **Belum pernah dipakai** sebelumnya
4. Jika tidak menjawab dalam waktu **15 detik** → tereliminasi
5. Pemain terakhir yang bertahan = **PEMENANG** 🏆

---

## ⚙️ KUSTOMISASI

### Ubah batas waktu giliran
Di `SambungKata_ServerScript.lua`, cari:
```lua
timeLimit = 15, -- detik per giliran
```
Ganti angka 15 sesuai keinginan.

### Tambah kata ke kamus
Di `SambungKata_ServerScript.lua`, cari tabel `Dictionary`:
```lua
local Dictionary = {
    -- tambahkan kata baru di sini
    "kata_baru", "kata_lain",
}
```

### Hanya admin yang bisa mulai game
Di bagian bawah ServerScript, uncomment bagian ini:
```lua
if player.UserId == 12345678 then  -- ganti dengan UserId kamu
```
Cari UserId kamu di: https://www.roblox.com/users/profile

---

## 🐛 TROUBLESHOOTING

| Masalah | Solusi |
|---------|--------|
| GUI tidak muncul | Pastikan LocalScript ada di StarterPlayerScripts |
| "Remotes folder tidak ditemukan" | Jalankan server dulu sebelum client |
| Kata valid tapi ditolak | Tambahkan kata tersebut ke tabel Dictionary |
| Game tidak bisa dimulai | Pastikan ada minimal 2 pemain/client |

---

## 📌 CATATAN
- Script ini 100% original buatan sendiri, aman untuk akun Roblox
- Kamu bisa expand kamus dengan lebih banyak kata bahasa Indonesia
- Sistem skor bisa diperluas dengan DataStore untuk persistent leaderboard
